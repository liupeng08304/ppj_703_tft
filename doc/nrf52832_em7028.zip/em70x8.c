#include <stdint.h>
#include <string.h>
#include "nordic_common.h"
#include "nrf52.h"

#include "app_timer.h"
#include <stdlib.h>
#include "nrf.h"
#include "nrf_soc.h"
#include "app_error.h"
#include "nrf_delay.h"
#include "app_util_platform.h"
#include "sdk_common.h"

//#include "app_error.h"
#include "nrf51_bitfields.h"
#include "ble.h"
#include "ble_hci.h"
//#include "ble_srv_common.h"
//#include "ble_advdata.h"
//#include "ble_advertising.h"
//#include "ble_bas.h"
//#include "ble_hrs.h"
//#include "ble_dis.h"
#ifdef BLE_DFU_APP_SUPPORT
#include "ble_dfu.h"
#include "dfu_app_handler.h"
#endif // BLE_DFU_APP_SUPPORT
//#include "ble_conn_params.h"
//#include "boards.h"
//#include "sensorsim.h"
//#include "softdevice_handler.h"
//#include "app_timer.h"
//#include "device_manager.h"
//#include "pstorage.h"
//#include "app_trace.h"
//#include "bsp.h"
#include "nrf_delay.h"

//#include "bsp_btn_ble.h"


//#define __EM7028_DEBUG__
#if defined(__EM7028_DEBUG__)
#define EM7028_TRACE  printf
#else
#define EM7028_TRACE
#endif

#define MOD_AUX		0
#define MOD_EM7028    MOD_AUX


#define kal_uint8	uint8_t
#define kal_bool  uint8_t
#define kal_uint16	uint16_t
#define KAL_TRUE	1
#define KAL_FALSE	0
static kal_bool faraway_hand_f=1;
static kal_bool faraway_cnt=0;
extern int em70xx_bpm_dynamic(int RECEIVED_BYTE, int g_sensor_x, int g_sensor_y, int g_sensor_z);
extern int em70xx_reset(int ref);
extern kal_bool HRS_WriteBytes(kal_uint8 RegAddr, kal_uint8 Data);
extern kal_bool HRS_ReadBytes(kal_uint8* Data, kal_uint8 RegAddr);
/*******************************************************************************
Modulm  Function
********************************************************************************/
void EM7028_hrs_get_data();

/**�Ĵ�����ַ*/
#define EM7028_PID_REG 			  0x00		
#define EM7028_ENABLE_REG 		  0x01	
#define EM7028_OFFSET_REG 		  0x08
#define EM7028_GAIN_REG 		  0x0A
#define EM7028_CONFIG_REG		  0x0D
#define EM7028_DRIVER_REG		  0x0E

/*******************************************************************************
********************************************************************************/
kal_uint8 EM7028_hrs_pid()
{
	kal_uint8  pid = 0x00;

	HRS_ReadBytes(&pid,0x00);

	return pid;
}	

void EM7028_hrs_init()
{
	HRS_WriteBytes(EM7028_ENABLE_REG,0x80);
	HRS_WriteBytes(EM7028_OFFSET_REG,0x00);
	HRS_WriteBytes(EM7028_GAIN_REG,0x7f);
	HRS_WriteBytes(EM7028_CONFIG_REG,0xc7);
	HRS_WriteBytes(EM7028_DRIVER_REG,0x06);
	//EM7028_hrs_pid();
	faraway_hand_f=1;
	em70xx_reset(0);
	EM7028_hrs_get_data();
}

void EM7028_hrs_get_data()
{
	kal_uint16 data = 0x00;
	kal_uint8  data_l = 0x00;
	kal_uint8  data_h = 0x00;
	kal_uint8  bpm_data = 0x00;

//	EM7028_TRACE(MOD_EM7028,"readByte******_data : %x ,data_l=%x,data_h=%x\n",data,data_l,data_h);
	if(faraway_hand_f)
	{
		HRS_ReadBytes(&data_l,0x20);
		HRS_ReadBytes(&data_h,0x21);
		data = (data_h <<8) | data_l;
		if(data > 10)
		{
			HRS_WriteBytes(EM7028_ENABLE_REG,0x08);
			faraway_hand_f=0;
			em70xx_reset(0);
		}
	}else{
		HRS_ReadBytes(&data_l,0x30);
		HRS_ReadBytes(&data_h,0x31);
		data = (data_h <<8) | data_l;
		if((data<12000||data >60000))
		{
			if(faraway_cnt==30){
				HRS_WriteBytes(EM7028_ENABLE_REG,0x80);
				em70xx_reset(0);
				faraway_hand_f=1;
			}else{
			   faraway_cnt++;
			}
		}else{
			faraway_cnt=0;
		}
	}
	bpm_data = em70xx_bpm_dynamic(data,0,0,0); //

	EM7028_TRACE(MOD_EM7028,"scan_bmp_data : %x \n",bpm_data);

	//StartTimer(ET_EM7028_TIMER_ID,30,EM7028_hrs_get_data);
}



void EM7028_enable(kal_uint8 enable)
{
	if(enable){
	
			HRS_WriteBytes(EM7028_ENABLE_REG,0x08);
			HRS_WriteBytes(EM7028_OFFSET_REG,0x00);
			HRS_WriteBytes(EM7028_GAIN_REG,0x7f);
			HRS_WriteBytes(EM7028_CONFIG_REG,0xc7);
			faraway_hand_f=1;
			em70xx_reset(0);
		}else{
			HRS_WriteBytes(EM7028_ENABLE_REG,0x00);
			HRS_WriteBytes(EM7028_CONFIG_REG,0x00);
			em70xx_reset(0);
		}

}


